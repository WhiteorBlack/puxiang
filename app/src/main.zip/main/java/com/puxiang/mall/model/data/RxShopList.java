package com.puxiang.mall.model.data;

import java.util.List;

/**
 * Created by zhaoyong bai on 2017/10/12.
 */

public class RxShopList {
    private int totalCount;
    private List<RxShop> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<RxShop> getList() {
        return list;
    }

    public void setList(List<RxShop> list) {
        this.list = list;
    }
}
