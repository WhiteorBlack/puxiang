package com.puxiang.mall.module.im.model;

public class MessageCount {
    private int count;

    public MessageCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
