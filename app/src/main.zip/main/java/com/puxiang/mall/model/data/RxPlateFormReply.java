package com.puxiang.mall.model.data;

public class RxPlateFormReply {
    private String replyContent;
    private String replyTime;
    private int postId;

    public String getReplyContent() {
        return replyContent;
    }

    public void setReplyContent(String replyContent) {
        this.replyContent = replyContent;
    }

    public String getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(String replyTime) {
        this.replyTime = replyTime;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return "{" +
                "replyContent='" + replyContent + '\'' +
                ", replyTime='" + replyTime + '\'' +
                ", postId=" + postId +
                '}';
    }
}
