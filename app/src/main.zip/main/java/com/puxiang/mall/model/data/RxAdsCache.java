package com.puxiang.mall.model.data;

import java.util.List;

public class RxAdsCache {
    private List<RxAds> list;

    public List<RxAds> getList() {
        return list;
    }

    public void setList(List<RxAds> list) {
        this.list = list;
    }
}
