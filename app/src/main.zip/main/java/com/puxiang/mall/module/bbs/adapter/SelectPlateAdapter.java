package com.puxiang.mall.module.bbs.adapter;

import com.puxiang.mall.adapter.BindingViewHolder;
import com.puxiang.mall.adapter.EasyBindQuickAdapter;
import com.puxiang.mall.model.data.RxPlate;

public class SelectPlateAdapter extends EasyBindQuickAdapter<RxPlate> {
    public SelectPlateAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void easyConvert(BindingViewHolder holder, RxPlate item) {
    }
}
