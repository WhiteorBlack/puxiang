package com.puxiang.mall.model.data;

import java.util.List;

public class RxPlateType {

    /**
     * id : 46
     * plates : [{"plateTypeCode":"huati","id":27,"createTime":"2016-11-28 09:16:54","plateNavigationPic":"attached/images/201611/31b7beb67f56496daf5b8c9b5e26b50883448.jpg?750x360","sort":101,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/b996442c96494514b0029d0d2b53a01952978.jpg?300x300","description":"晒个美食！首次参与话题，200积分相送~","plateName":"吃货速速现身","attentionQty":8,"postQty":2,"plateTypeId":46,"plateIntroduce":"冬天夏天，南方北方，吃之道大不同，吃货们上图！"},{"plateTypeCode":"huati","id":20,"createTime":"2016-10-21 14:53:09","plateNavigationPic":"attached/images/201611/cf7e1b52132a4b2eacdf96ac8d2020dd74401.jpg","sort":100,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/3471081380e24823872288a46b53c96a54151.jpg","description":"【活动进行时】上传自拍美照，就有机会获得礼品大奖哦。","plateName":"硕粉们，SHOW出来","attentionQty":13,"postQty":51,"plateTypeId":46,"plateIntroduce":"【活动进行时】上传自拍美照，就有机会获得礼品大奖哦。"},{"plateTypeCode":"huati","id":26,"createTime":"2016-11-21 09:14:13","plateNavigationPic":"attached/images/201611/af31325c55b3477a93819dcebd5cd8ea04615.jpg?750x360","sort":99,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/18a36efd5980496facab30948badee3083345.jpg?300x300","description":"来聊聊龙叔吧！首次参与话题，200积分相送~","plateName":"Duang~成龙得了奥斯卡","attentionQty":10,"postQty":4,"plateTypeId":46,"plateIntroduce":"他是逗比？硬汉？还是表情包？来说说成龙或者他参演的电影吧~"},{"plateTypeCode":"huati","id":7,"createTime":"2016-08-09 17:19:18","plateNavigationPic":"attached/images/201611/ffe8c7ad6b2e4bc5912211c7ed084d3f75548.jpg","sort":98,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/7d3c8c5f5a1c4f96945717749a4d3d4079047.jpg","description":"有什么不开心的事，说出来让大家开心下。","plateName":"糗事大家乐","attentionQty":15,"postQty":350,"plateTypeId":46,"plateIntroduce":"有什么不开心的事，说出来让大家开心下。"},{"plateTypeCode":"huati","id":2,"createTime":"2016-08-09 16:17:19","plateNavigationPic":"attached/images/201610/407b5aef12484d17a39d8e8afd1fd0e550848.jpg","sort":97,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/db1b9b56ba874eeeba760f80f517f0e808006.jpg","description":"有没有一首歌让你梦绕魂牵，来分享下吧。","plateName":"有没有一首歌","attentionQty":25,"postQty":142,"plateTypeId":46,"plateIntroduce":"有没有一首歌让你梦绕魂牵，来分享下吧。"},{"plateTypeCode":"huati","id":21,"createTime":"2016-10-21 15:16:58","plateNavigationPic":"attached/images/201611/914db3c4db2b412bb1015b50fb02228a32643.jpg","sort":96,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/c25c9e9ee54f4bb6a5c890abbcf0b25b47270.jpg","description":"正确地看片与正确的看片姿势。","plateName":"看片","attentionQty":9,"postQty":68,"plateTypeId":46,"plateIntroduce":"正确地看片与正确的看片姿势。"},{"plateTypeCode":"huati","id":19,"createTime":"2016-10-21 14:51:18","plateNavigationPic":"attached/images/201611/ee7270f1f0a743f9a85ac25ed027257986739.jpg","sort":95,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/0594f0f561954e85ab5f1c7dde05fc5056033.jpg","description":"还看！要开车了！","plateName":"老司机俱乐部","attentionQty":8,"postQty":33,"plateTypeId":46,"plateIntroduce":"还看！要开车了！"},{"plateTypeCode":"huati","id":24,"createTime":"2016-10-31 10:15:15","plateNavigationPic":"attached/images/201611/2ba355ee6afd48e0b2d90c2b10cdcdb153591.jpg","sort":94,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/26a0c41d1e2040e487e06f0504a80f9448883.jpg","description":"人人都爱看猫片。","plateName":"人人都爱看猫片","attentionQty":10,"postQty":72,"plateTypeId":46,"plateIntroduce":"咱们就要萌萌哒~"},{"plateTypeCode":"huati","id":25,"createTime":"2016-11-01 09:45:38","plateNavigationPic":"attached/images/201611/8d09a85adc7842a1a590facdd614b59a41668.jpg","sort":93,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/53ae5fc5ab974f3fbd50c4ed103d78e589318.jpg","description":"灌水，灌水，都来灌水！","plateName":"灌满太平洋","attentionQty":7,"postQty":232,"plateTypeId":46,"plateIntroduce":"灌水，灌水，都来灌水！"},{"plateTypeCode":"huati","id":22,"createTime":"2016-10-21 15:22:32","plateNavigationPic":"attached/images/201611/a483dc6f3e114eebbb4e84368aa447ca32391.jpg","sort":92,"isAttented":null,"platePic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/96aac7f6a1ac43c4bb3df411845cbe5e39944.jpg","description":"夜深了，是不是该干点什么了!","plateName":"深夜胡话","attentionQty":3,"postQty":8,"plateTypeId":46,"plateIntroduce":"夜深了，是不是该干点什么了!"}]
     * name : 热门话题
     */
    private int id;
    private String name;
    /**
     * plateTypeCode : huati
     * id : 27
     * createTime : 2016-11-28 09:16:54
     * plateNavigationPic : attached/images/201611/31b7beb67f56496daf5b8c9b5e26b50883448.jpg?750x360
     * sort : 101
     * isAttented : null
     * platePic : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/b996442c96494514b0029d0d2b53a01952978.jpg?300x300
     * description : 晒个美食！首次参与话题，200积分相送~
     * plateName : 吃货速速现身
     * attentionQty : 8
     * postQty : 2
     * plateTypeId : 46
     * plateIntroduce : 冬天夏天，南方北方，吃之道大不同，吃货们上图！
     */

    private List<RxPlate> plates;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<RxPlate> getPlates() {
        return plates;
    }

    public void setPlates(List<RxPlate> plates) {
        this.plates = plates;
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", plates=" + plates +
                '}';
    }
}
