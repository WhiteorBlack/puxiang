package com.puxiang.mall.network.retrofit;

public class Constant {

    /**
     * 查阅消息-评论我的
     */
    public static final String MESSAGE_CODE_COMMENT_ME = "commentMe";
    /**
     * 查阅消息-赞我的
     */
    public static final String MESSAGE_CODE_LIKE_ME = "likeMe";
}
