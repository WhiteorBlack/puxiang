package com.puxiang.mall.model.data;

import java.util.List;

/**
 * Created by zhaoyong bai on 2017/9/19.
 */

public class RxOrder {
    public String shopId;
    public String userId;
    public List<Product> products;
    public static class Product{
        public String productId;
        public String buyQty;
        public String skuId;
        public String cartId;
    }
}
