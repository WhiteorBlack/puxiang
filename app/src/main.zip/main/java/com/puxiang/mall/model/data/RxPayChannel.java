package com.puxiang.mall.model.data;


public class RxPayChannel {

    public static final String PAY_CHANNEL_ALIPAY = "Alipay";
    public static final String PAY_CHANNEL_WEIXIN = "Weixin";
    public static final String PAY_CHANNEL_UNIONPAY = "Unionpay";

    /**
     * id : 1
     * icon : http://somicshop.oss-cn-shenzhen.aliyuncs
     * .com/attached/images/201704/8a806fe4c6f149de8f1c50597b0453e668936.jpg?168x168
     * name : 支付宝支付
     * code : Alipay
     */

    private int id;
    private String icon;
    private String name;
    private String code;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
