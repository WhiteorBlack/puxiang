package com.puxiang.mall.config;

/**
 * 帖子外链类型
 */
public interface ListType {
    String LINK_PRODUCT = "product";
    String LINK_POST = "post";
    String LINK_PLATE = "plate";
    String LINK_PLATE_TYPE = "plateType";
    String LINK_ACTIVITY = "activity";
    String LINK_INTEGRAL_TASK = "integralTask";
    String LINK_INTEGRAL_MALL = "integralMall";
    String LINK_CHANNEL = "channel";
    String LINK_HTML = "html";
    String LINK_H5 = "h5";
    String LINK_AI = "ai";
    String LINK_ESPORT = "esport";
    String LINK_SEARCH="search";
}
