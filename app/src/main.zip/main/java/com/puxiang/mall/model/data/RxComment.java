package com.puxiang.mall.model.data;

public class RxComment {
    private String id;
    private int commentQty;
    private String commentTime;
    private String comment;
    private String commentUserId;
    private int likeQty;
    private int postId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCommentQty() {
        return commentQty;
    }

    public void setCommentQty(int commentQty) {
        this.commentQty = commentQty;
    }

    public String getCommentTime() {
        return commentTime;
    }

    public void setCommentTime(String commentTime) {
        this.commentTime = commentTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCommentUserId() {
        return commentUserId;
    }

    public void setCommentUserId(String commentUserId) {
        this.commentUserId = commentUserId;
    }

    public int getLikeQty() {
        return likeQty;
    }

    public void setLikeQty(int likeQty) {
        this.likeQty = likeQty;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }
}
