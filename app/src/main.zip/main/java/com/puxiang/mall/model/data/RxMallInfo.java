package com.puxiang.mall.model.data;

import android.databinding.BaseObservable;

import java.util.List;

/**
 * Created by zhaoyong bai on 2017/10/16.
 */

public class RxMallInfo extends BaseObservable {
    public String desc;
    public List<RxProduct> data;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public List<RxProduct> getData() {
        return data;
    }

    public void setData(List<RxProduct> data) {
        this.data = data;
    }
}
