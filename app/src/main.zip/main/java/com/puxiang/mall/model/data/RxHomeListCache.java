package com.puxiang.mall.model.data;

import java.util.List;

public class RxHomeListCache {
    private List<RxPostInfo> list;

    public List<RxPostInfo> getList() {
        return list;
    }

    public void setList(List<RxPostInfo> list) {
        this.list = list;
    }
}
