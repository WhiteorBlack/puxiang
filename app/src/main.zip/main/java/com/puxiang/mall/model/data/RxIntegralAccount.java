package com.puxiang.mall.model.data;

public class RxIntegralAccount {


    /**
     * balance : 2750.0
     * totalScore : 2750.0
     * userId : 433
     */

    private int balance;
    private int totalScore;
    private int userId;

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
