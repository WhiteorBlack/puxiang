package com.puxiang.mall.model.data;

import java.util.List;

public class RxReplyPostComment {

    /**
     * commentQty : 1
     * commentUser : {"birthday":"","sex":null,"viewName":"哈哈","nickname":"哈哈","userId":433,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/23e68d3f7839492b900982f559b3343b74207.jpg","userName":"M000000420"}
     * title : 这样的房间我也想要！
     * postType : 1
     * replys : [{"byReplyUser":{"birthday":"","sex":null,"viewName":"哈哈","nickname":"哈哈","userId":433,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/23e68d3f7839492b900982f559b3343b74207.jpg","userName":"M000000420"},"commentUser":{"birthday":"","sex":2,"viewName":"猫樣","nickname":"猫樣","userId":64,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/280f03a405ed4cf2a292a964ad8f8e7833832.jpg","userName":"M000000052"},"commentReply":{"id":343,"replyUserId":64,"reply":"你够了←_←","byReplyUserId":433,"replyTime":"2016-11-25 13:54:20","commentId":2148}}]
     * isAttented : false
     * commentTime : 2016-11-25 11:28:42
     * isOwner : true
     * comment : 隔壁老王专用
     * likeQty : 0
     * commentId : 2148
     * postId : 2797
     */

    private int commentQty;
    /**
     * birthday :
     * sex : null
     * viewName : 哈哈
     * nickname : 哈哈
     * userId : 433
     * userImage : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/23e68d3f7839492b900982f559b3343b74207.jpg
     * userName : M000000420
     */

    private RxUserInfo commentUser;
    private String title;
    private int postType;
    private String isAttented;
    private String commentTime;
    private boolean isOwner;
    private String comment;
    private int likeQty;
    private String commentId;
    private String postId;
    /**
     * byReplyUser : {"birthday":"","sex":null,"viewName":"哈哈","nickname":"哈哈","userId":433,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/23e68d3f7839492b900982f559b3343b74207.jpg","userName":"M000000420"}
     * commentUser : {"birthday":"","sex":2,"viewName":"猫樣","nickname":"猫樣","userId":64,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/280f03a405ed4cf2a292a964ad8f8e7833832.jpg","userName":"M000000052"}
     * commentReply : {"id":343,"replyUserId":64,"reply":"你够了←_←","byReplyUserId":433,"replyTime":"2016-11-25 13:54:20","commentId":2148}
     */

    private List<RxReply> replys;

    public int getCommentQty() {
        return commentQty;
    }

    public void setCommentQty(int commentQty) {
        this.commentQty = commentQty;
    }

    public RxUserInfo getCommentUser() {
        return commentUser;
    }

    public void setCommentUser(RxUserInfo commentUser) {
        this.commentUser = commentUser;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPostType() {
        return postType;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public String getIsAttented() {
        return isAttented;
    }

    public void setIsAttented(String isAttented) {
        this.isAttented = isAttented;
    }

    public String getCommentTime() {
        return commentTime;
    }

    public void setCommentTime(String commentTime) {
        this.commentTime = commentTime;
    }

    public boolean getIsOwner() {
        return isOwner;
    }

    public void setIsOwner(boolean isOwner) {
        this.isOwner = isOwner;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getLikeQty() {
        return likeQty;
    }

    public void setLikeQty(int likeQty) {
        this.likeQty = likeQty;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public List<RxReply> getReplys() {
        return replys;
    }

    public void setReplys(List<RxReply> replys) {
        this.replys = replys;
    }
}
