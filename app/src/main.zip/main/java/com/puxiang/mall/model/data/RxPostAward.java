package com.puxiang.mall.model.data;

public class RxPostAward {
    private int awardScore;
    private String awardRemark;
    private int postId;

    public int getAwardScore() {
        return awardScore;
    }

    public void setAwardScore(int awardScore) {
        this.awardScore = awardScore;
    }

    public String getAwardRemark() {
        return awardRemark;
    }

    public void setAwardRemark(String awardRemark) {
        this.awardRemark = awardRemark;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }
}
