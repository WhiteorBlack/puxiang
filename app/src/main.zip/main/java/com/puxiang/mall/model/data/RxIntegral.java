package com.puxiang.mall.model.data;

import java.util.List;

public class RxIntegral {

    /**
     * totalScore : 200.0
     * taskType : 3
     * score : 0.0
     * tasks : [{"id":20,"sort":14,"taskIntroduce":"好玩不好玩的手游，都来说一下！首次参与话题送200积分。","taskQty":1,"taskType":3,"taskBusinessId":28,"taskState":1,"taskUnitScore":200,"taskCode":"replyTopic","taskName":"说说你玩过的手游","url":"http://mbbs.esomic.com/round_page.html?plateId=28","completed":false}]
     * taskTypeName : 热门活动
     */

    private int totalScore;
    private int taskType;
    private int score;
    private String taskTypeName;
    /**
     * id : 20
     * sort : 14
     * taskIntroduce : 好玩不好玩的手游，都来说一下！首次参与话题送200积分。
     * taskQty : 1
     * taskType : 3
     * taskBusinessId : 28
     * taskState : 1
     * taskUnitScore : 200.0
     * taskCode : replyTopic
     * taskName : 说说你玩过的手游
     * url : http://mbbs.esomic.com/round_page.html?plateId=28
     * completed : false
     */

    private List<RxTasks> tasks;

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getTaskType() {
        return taskType;
    }

    public void setTaskType(int taskType) {
        this.taskType = taskType;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getTaskTypeName() {
        return taskTypeName;
    }

    public void setTaskTypeName(String taskTypeName) {
        this.taskTypeName = taskTypeName;
    }

    public List<RxTasks> getTasks() {
        return tasks;
    }

    public void setTasks(List<RxTasks> tasks) {
        this.tasks = tasks;
    }

}
