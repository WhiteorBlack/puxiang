package com.puxiang.mall.model.data;

import java.util.List;

public class RxMallCache {
    private List<RxProduct> list;

    public List<RxProduct> getList() {
        return list;
    }

    public void setList(List<RxProduct> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "{list=" + list +'}';
    }
}
