package com.puxiang.mall.model.data;

import java.util.List;

public class RxUnreadMessageListCache {
    private List<RxUnreadMessage> list;

    public List<RxUnreadMessage> getList() {
        return list;
    }

    public void setList(List<RxUnreadMessage> list) {
        this.list = list;
    }
}
