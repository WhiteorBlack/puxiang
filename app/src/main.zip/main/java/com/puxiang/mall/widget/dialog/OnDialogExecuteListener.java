package com.puxiang.mall.widget.dialog;

public interface OnDialogExecuteListener {
    void execute();

    void cancel();
}
