package com.puxiang.mall.model.data;

import cn.finalteam.galleryfinal.model.PhotoInfo;

/**
 * Created by zhaoyong bai on 2017/9/21.
 */

public class RxPhotoInfo extends PhotoInfo {
    private String photoUri;

    public String getPhotoUri() {
        return photoUri;
    }

    public void setPhotoUri(String photoUri) {
        this.photoUri = photoUri;
    }
}
