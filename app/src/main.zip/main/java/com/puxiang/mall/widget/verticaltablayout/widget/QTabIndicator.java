package com.puxiang.mall.widget.verticaltablayout.widget;

public class QTabIndicator extends TabIndicator{
    public QTabIndicator(){

    }
}
