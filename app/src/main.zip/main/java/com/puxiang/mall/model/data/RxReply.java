package com.puxiang.mall.model.data;

public class RxReply {
    /**
     * birthday :
     * sex : null
     * viewName : 哈哈
     * nickname : 哈哈
     * userId : 433
     * userImage : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/23e68d3f7839492b900982f559b3343b74207.jpg
     * userName : M000000420
     */

    private RxUserInfo byReplyUser;
    /**
     * birthday :
     * sex : 2
     * viewName : 猫樣
     * nickname : 猫樣
     * userId : 64
     * userImage : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/280f03a405ed4cf2a292a964ad8f8e7833832.jpg
     * userName : M000000052
     */

    private RxUserInfo commentUser;
    /**
     * id : 343
     * replyUserId : 64
     * reply : 你够了←_←
     * byReplyUserId : 433
     * replyTime : 2016-11-25 13:54:20
     * commentId : 2148
     */

    private RxCommentReply commentReply;

    public RxUserInfo getByReplyUser() {
        return byReplyUser;
    }

    public void setByReplyUser(RxUserInfo byReplyUser) {
        this.byReplyUser = byReplyUser;
    }

    public RxUserInfo getCommentUser() {
        return commentUser;
    }

    public void setCommentUser(RxUserInfo commentUser) {
        this.commentUser = commentUser;
    }

    public RxCommentReply getCommentReply() {
        return commentReply;
    }

    public void setCommentReply(RxCommentReply commentReply) {
        this.commentReply = commentReply;
    }
}
