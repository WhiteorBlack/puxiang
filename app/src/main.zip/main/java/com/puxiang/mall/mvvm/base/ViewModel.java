package com.puxiang.mall.mvvm.base;

public interface ViewModel {
    void destroy();
}
