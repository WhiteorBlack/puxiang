package com.puxiang.mall.model.data;

public class RxRefundReasons {
    private String refundReasonDes;
    private int refundReasonId;

    public String getRefundReasonDes() {
        return refundReasonDes;
    }

    public void setRefundReasonDes(String refundReasonDes) {
        this.refundReasonDes = refundReasonDes;
    }

    public int getRefundReasonId() {
        return refundReasonId;
    }

    public void setRefundReasonId(int refundReasonId) {
        this.refundReasonId = refundReasonId;
    }
}
