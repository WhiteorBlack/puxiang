package com.puxiang.mall.model.data;

public class RxCheck {

    /**
     * desc : 可以修改
     * changeAble : 1
     */

    private String desc;
    private int changeAble;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getChangeAble() {
        return changeAble;
    }

    public void setChangeAble(int changeAble) {
        this.changeAble = changeAble;
    }
}
