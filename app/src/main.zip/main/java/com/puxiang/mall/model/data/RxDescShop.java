package com.puxiang.mall.model.data;

import android.databinding.BaseObservable;
import android.databinding.Bindable;
import android.databinding.ObservableBoolean;

import com.puxiang.mall.BR;

/**
 * Created by zhaoyong bai on 2017/10/18.
 */

public class RxDescShop  {
    private String descName;
    private String descCode;
    private boolean isSelect=false;

    public void setIsSelect(boolean isSelect) {
        this.isSelect = isSelect;
    }

    public boolean getIsSelect() {
        return isSelect;
    }

    public String getDescName() {
        return descName;
    }

    public void setDescName(String descName) {
        this.descName = descName;
    }

    public String getDescCode() {
        return descCode;
    }

    public void setDescCode(String descCode) {
        this.descCode = descCode;
    }
}
