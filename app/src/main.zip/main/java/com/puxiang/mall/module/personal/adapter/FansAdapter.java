package com.puxiang.mall.module.personal.adapter;

import com.puxiang.mall.R;
import com.puxiang.mall.adapter.BindingViewHolder;
import com.puxiang.mall.adapter.EasyBindQuickAdapter;
import com.puxiang.mall.model.data.RxFans;

public class FansAdapter extends EasyBindQuickAdapter<RxFans> {
    public FansAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void easyConvert(BindingViewHolder holder, RxFans item) {
        holder.addOnClickListener(R.id.tv_attention);
    }
}
