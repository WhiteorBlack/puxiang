package com.puxiang.mall.model.data;

import java.util.List;


public class LocationInfo {

    /**
     * results : [{"address_components":[{"long_name":"416","short_name":"416","types":["street_number"]},{"long_name":"五泉南路","short_name":"五泉南路","types":["route"]},{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省兰州市城关区五泉南路416号","geometry":{"location":{"lat":36.04015,"lng":103.822653},"location_type":"ROOFTOP","viewport":{"northeast":{"lat":36.0414989802915,"lng":103.8240019802915},"southwest":{"lat":36.0388010197085,"lng":103.8213040197085}}},"place_id":"ChIJvTkkkd-TWjYRnow4h9hOcB4","types":["street_address"]},{"address_components":[{"long_name":"市政大坡南口","short_name":"市政大坡南口","types":["bus_station","establishment","point_of_interest","transit_station"]},{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]},{"long_name":"730030","short_name":"730030","types":["postal_code"]}],"formatted_address":"中国兰州市城关区市政大坡南口 邮政编码: 730030","geometry":{"location":{"lat":36.0423002,"lng":103.8224467},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":36.0436491802915,"lng":103.8237956802915},"southwest":{"lat":36.0409512197085,"lng":103.8210977197085}}},"place_id":"ChIJnRXKCOCTWjYRdJ4kP3HTQSM","types":["bus_station","establishment","point_of_interest","transit_station"]},{"address_components":[{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省兰州市城关区","geometry":{"bounds":{"northeast":{"lat":36.1593449,"lng":103.9854488},"southwest":{"lat":35.9618686,"lng":103.7795754}},"location":{"lat":36.057464,"lng":103.825308},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":36.1593449,"lng":103.9854488},"southwest":{"lat":35.9618686,"lng":103.7795754}}},"place_id":"ChIJbysAYpyUWjYRzFejI78s6BA","types":["political","sublocality","sublocality_level_1"]},{"address_components":[{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省兰州市","geometry":{"bounds":{"northeast":{"lat":36.9991552,"lng":104.5772687},"southwest":{"lat":35.5711356,"lng":102.6012757}},"location":{"lat":36.061089,"lng":103.834304},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":36.2582568,"lng":104.0432739},"southwest":{"lat":35.8984926,"lng":103.4788513}}},"place_id":"ChIJgzkMmbWQWjYRXCQNXS4ATJE","types":["locality","political"]},{"address_components":[{"long_name":"730000","short_name":"730000","types":["postal_code"]},{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省兰州市城关区 邮政编码: 730000","geometry":{"bounds":{"northeast":{"lat":36.324068,"lng":103.949205},"southwest":{"lat":36.0246086,"lng":103.617461}},"location":{"lat":36.05564580000001,"lng":103.8565903},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":36.0820309,"lng":103.9042488},"southwest":{"lat":36.0246086,"lng":103.8085851}}},"place_id":"ChIJm58qIYaTWjYR95z4-teHUt4","types":["postal_code"]},{"address_components":[{"long_name":"730030","short_name":"730030","types":["postal_code"]},{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省兰州市城关区 邮政编码: 730030","geometry":{"bounds":{"northeast":{"lat":36.088668,"lng":103.965161},"southwest":{"lat":36.0065181,"lng":103.7202285}},"location":{"lat":36.0572166,"lng":103.8252037},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":36.0786269,"lng":103.8752528},"southwest":{"lat":36.0338312,"lng":103.8042381}}},"place_id":"ChIJe4BlL_yTWjYRyPHZr-psvw4","types":["postal_code"]},{"address_components":[{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国甘肃省","geometry":{"bounds":{"northeast":{"lat":42.7951629,"lng":108.7123363},"southwest":{"lat":32.5941106,"lng":92.33914659999999}},"location":{"lat":36.059561,"lng":103.826447},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":42.7951629,"lng":108.7123363},"southwest":{"lat":32.5941106,"lng":92.33914659999999}}},"place_id":"ChIJ5bRHsW5cTDYR2b_TuLO4yq8","types":["administrative_area_level_1","political"]},{"address_components":[{"long_name":"中国","short_name":"CN","types":["country","political"]}],"formatted_address":"中国","geometry":{"bounds":{"northeast":{"lat":53.56097399999999,"lng":134.7728099},"southwest":{"lat":17.9996,"lng":73.4994136}},"location":{"lat":35.86166,"lng":104.195397},"location_type":"APPROXIMATE","viewport":{"northeast":{"lat":53.56097399999999,"lng":134.7726951},"southwest":{"lat":18.1618061,"lng":73.5034261}}},"place_id":"ChIJwULG5WSOUDERbzafNHyqHZU","types":["country","political"]}]
     * status : OK
     */

    private String status;
    private List<ResultsBean> results;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ResultsBean> getResults() {
        return results;
    }

    public void setResults(List<ResultsBean> results) {
        this.results = results;
    }

    public static class ResultsBean {
        /**
         * address_components : [{"long_name":"416","short_name":"416","types":["street_number"]},{"long_name":"五泉南路","short_name":"五泉南路","types":["route"]},{"long_name":"城关区","short_name":"城关区","types":["political","sublocality","sublocality_level_1"]},{"long_name":"兰州市","short_name":"兰州市","types":["locality","political"]},{"long_name":"甘肃省","short_name":"甘肃省","types":["administrative_area_level_1","political"]},{"long_name":"中国","short_name":"CN","types":["country","political"]}]
         * formatted_address : 中国甘肃省兰州市城关区五泉南路416号
         * geometry : {"location":{"lat":36.04015,"lng":103.822653},"location_type":"ROOFTOP","viewport":{"northeast":{"lat":36.0414989802915,"lng":103.8240019802915},"southwest":{"lat":36.0388010197085,"lng":103.8213040197085}}}
         * place_id : ChIJvTkkkd-TWjYRnow4h9hOcB4
         * types : ["street_address"]
         */

        private String formatted_address;
        private GeometryBean geometry;
        private String place_id;
        private List<AddressComponentsBean> address_components;
        private List<String> types;

        public String getFormatted_address() {
            return formatted_address;
        }

        public void setFormatted_address(String formatted_address) {
            this.formatted_address = formatted_address;
        }

        public GeometryBean getGeometry() {
            return geometry;
        }

        public void setGeometry(GeometryBean geometry) {
            this.geometry = geometry;
        }

        public String getPlace_id() {
            return place_id;
        }

        public void setPlace_id(String place_id) {
            this.place_id = place_id;
        }

        public List<AddressComponentsBean> getAddress_components() {
            return address_components;
        }

        public void setAddress_components(List<AddressComponentsBean> address_components) {
            this.address_components = address_components;
        }

        public List<String> getTypes() {
            return types;
        }

        public void setTypes(List<String> types) {
            this.types = types;
        }

        public static class GeometryBean {
            /**
             * location : {"lat":36.04015,"lng":103.822653}
             * location_type : ROOFTOP
             * viewport : {"northeast":{"lat":36.0414989802915,"lng":103.8240019802915},"southwest":{"lat":36.0388010197085,"lng":103.8213040197085}}
             */

            private LocationBean location;
            private String location_type;
            private ViewportBean viewport;

            public LocationBean getLocation() {
                return location;
            }

            public void setLocation(LocationBean location) {
                this.location = location;
            }

            public String getLocation_type() {
                return location_type;
            }

            public void setLocation_type(String location_type) {
                this.location_type = location_type;
            }

            public ViewportBean getViewport() {
                return viewport;
            }

            public void setViewport(ViewportBean viewport) {
                this.viewport = viewport;
            }

            public static class LocationBean {
                /**
                 * lat : 36.04015
                 * lng : 103.822653
                 */

                private double lat;
                private double lng;

                public double getLat() {
                    return lat;
                }

                public void setLat(double lat) {
                    this.lat = lat;
                }

                public double getLng() {
                    return lng;
                }

                public void setLng(double lng) {
                    this.lng = lng;
                }
            }

            public static class ViewportBean {
                /**
                 * northeast : {"lat":36.0414989802915,"lng":103.8240019802915}
                 * southwest : {"lat":36.0388010197085,"lng":103.8213040197085}
                 */

                private NortheastBean northeast;
                private SouthwestBean southwest;

                public NortheastBean getNortheast() {
                    return northeast;
                }

                public void setNortheast(NortheastBean northeast) {
                    this.northeast = northeast;
                }

                public SouthwestBean getSouthwest() {
                    return southwest;
                }

                public void setSouthwest(SouthwestBean southwest) {
                    this.southwest = southwest;
                }

                public static class NortheastBean {
                    /**
                     * lat : 36.0414989802915
                     * lng : 103.8240019802915
                     */

                    private double lat;
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }

                public static class SouthwestBean {
                    /**
                     * lat : 36.0388010197085
                     * lng : 103.8213040197085
                     */

                    private double lat;
                    private double lng;

                    public double getLat() {
                        return lat;
                    }

                    public void setLat(double lat) {
                        this.lat = lat;
                    }

                    public double getLng() {
                        return lng;
                    }

                    public void setLng(double lng) {
                        this.lng = lng;
                    }
                }
            }
        }

        public static class AddressComponentsBean {
            /**
             * long_name : 416
             * short_name : 416
             * types : ["street_number"]
             */

            private String long_name;
            private String short_name;
            private List<String> types;

            public String getLong_name() {
                return long_name;
            }

            public void setLong_name(String long_name) {
                this.long_name = long_name;
            }

            public String getShort_name() {
                return short_name;
            }

            public void setShort_name(String short_name) {
                this.short_name = short_name;
            }

            public List<String> getTypes() {
                return types;
            }

            public void setTypes(List<String> types) {
                this.types = types;
            }
        }
    }
}
