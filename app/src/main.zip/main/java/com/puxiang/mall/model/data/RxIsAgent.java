package com.puxiang.mall.model.data;


public class RxIsAgent {

    /**
     * status : 1
     */

    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
