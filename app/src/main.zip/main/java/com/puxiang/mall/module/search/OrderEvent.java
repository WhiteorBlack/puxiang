package com.puxiang.mall.module.search;

public class OrderEvent {


    private String type;
    private String order;

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public OrderEvent(String order, String type) {
        this.order = order;
        this.type = type;
    }
}
