package com.puxiang.mall.model.data;

public class AppVersionJSON {

    /**
     * errorMessage : 业务操作成功
     * returnObject : {"id":1,"createTime":"2016-08-10 10:43:30","versionFile":"","introduceDetail":"硕美科V2.0","introduce":"硕美科V2.0","versionCode":2,"versionType":1,"versionName":"硕美科V2.0","modifyTime":"2016-08-10 10:43:30"}
     * token :
     * errorCode : 000
     */

    private String errorMessage;
    /**
     * id : 1
     * createTime : 2016-08-10 10:43:30
     * versionFile :
     * introduceDetail : 硕美科V2.0
     * introduce : 硕美科V2.0
     * versionCode : 2
     * versionType : 1
     * versionName : 硕美科V2.0
     * modifyTime : 2016-08-10 10:43:30
     */

    private ReturnObjectBean returnObject;
    private String token;
    private String errorCode;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public ReturnObjectBean getReturnObject() {
        return returnObject;
    }

    public void setReturnObject(ReturnObjectBean returnObject) {
        this.returnObject = returnObject;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public static class ReturnObjectBean {
        private int id;
        private String createTime;
        private String versionFile;
        private String introduceDetail;
        private String introduce;
        private int versionCode;
        private int versionType;
        private String versionName;
        private String modifyTime;

        private int isMustUpdate;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getVersionFile() {
            return versionFile;
        }

        public void setVersionFile(String versionFile) {
            this.versionFile = versionFile;
        }

        public String getIntroduceDetail() {
            return introduceDetail;
        }

        public void setIntroduceDetail(String introduceDetail) {
            this.introduceDetail = introduceDetail;
        }

        public String getIntroduce() {
            return introduce;
        }

        public void setIntroduce(String introduce) {
            this.introduce = introduce;
        }

        public int getVersionCode() {
            return versionCode;
        }

        public void setVersionCode(int versionCode) {
            this.versionCode = versionCode;
        }

        public int getVersionType() {
            return versionType;
        }

        public void setVersionType(int versionType) {
            this.versionType = versionType;
        }

        public String getVersionName() {
            return versionName;
        }

        public void setVersionName(String versionName) {
            this.versionName = versionName;
        }

        public String getModifyTime() {
            return modifyTime;
        }

        public void setModifyTime(String modifyTime) {
            this.modifyTime = modifyTime;
        }

        public int getIsMustUpdate() {
            return isMustUpdate;
        }

        public void setIsMustUpdate(int isMustUpdate) {
            this.isMustUpdate = isMustUpdate;
        }
    }
}
