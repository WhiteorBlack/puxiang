package com.puxiang.mall.wxapi;

public class PayEvent {

}
