package com.puxiang.mall;

//import com.umeng.socialize.media.WBShareCallBackActivity;

import com.umeng.socialize.media.WBShareCallBackActivity;

public class WBShareActivity extends WBShareCallBackActivity {
}
