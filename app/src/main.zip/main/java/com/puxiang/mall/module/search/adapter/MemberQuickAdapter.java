package com.puxiang.mall.module.search.adapter;

import android.widget.TextView;

import com.puxiang.mall.R;
import com.puxiang.mall.adapter.BindingViewHolder;
import com.puxiang.mall.adapter.EasyBindQuickAdapter;
import com.puxiang.mall.model.data.RxUserInfo;

public class MemberQuickAdapter extends EasyBindQuickAdapter<RxUserInfo> {

    public MemberQuickAdapter(int layoutResId) {
        super(layoutResId);
    }

    public void setEmptyViewText(String str) {
        TextView none_tv = (TextView) getEmptyView().findViewById(R.id.tv_none);
        none_tv.setText(str);
    }

    @Override
    protected void easyConvert(BindingViewHolder holder, RxUserInfo item) {

    }
}
