package com.puxiang.mall.module.emotion.model;

import android.graphics.drawable.Drawable;

/**
 * Time  16/1/5 下午5:57
 * Description:底部tab图片对象
 */
public class ImageModel {

    public String flag=null;//说明文本
    public Drawable icon=null;//图标
    public boolean isSelected=false;//是否被选中

}
