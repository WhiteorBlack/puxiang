package com.puxiang.mall.model.data;

import java.util.List;

public class RxVideosData {

    /**
     * post : {"linkUrl":null,"postUserId":null,"likeQty":146,"readQty":119,"orderDetailId":null,"id":1410,"title":"蓝瘦，香菇！！！","postTypeId":30,"isTop":0,"isRecommend":0,"commentQty":1,"plateId":null,"picUrl":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201610/834c9bcdc23e4e209a03d04944f7dbc919310.jpg?344x344","postType":3,"publishTime":"2016-10-11 10:29:20","videoUrl":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/videos/201610/893b34b2fc6a419b823c0772e0d8f58c22847.mp4","linkType":null,"productInfo":null,"isHot":0,"isHotPost":0,"content":"\u201c蓝瘦香菇\u201d迅速走红网络，出处就在这里啦~","linkId":null,"source":"网络","playQty":2,"topTime":null,"postTypeName":"趣事趣闻视频"}
     * isAttented : false
     * plate : {"createTime":null,"plateNavigationPic":"","sort":null,"isAttented":null,"postQty":null,"id":null,"plateTypeCode":"qushivideo","plateType":null,"platePic":null,"plateName":null,"description":null,"attentionQty":null,"plateTypeId":30,"plateIntroduce":null}
     * isLiked : false
     * isOwner : false
     * account : null
     * hasReply : false
     */

    private List<ListBean> list;

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * linkUrl : null
         * postUserId : null
         * likeQty : 146
         * readQty : 119
         * orderDetailId : null
         * id : 1410
         * title : 蓝瘦，香菇！！！
         * postTypeId : 30
         * isTop : 0
         * isRecommend : 0
         * commentQty : 1
         * plateId : null
         * picUrl : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201610/834c9bcdc23e4e209a03d04944f7dbc919310.jpg?344x344
         * postType : 3
         * publishTime : 2016-10-11 10:29:20
         * videoUrl : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/videos/201610/893b34b2fc6a419b823c0772e0d8f58c22847.mp4
         * linkType : null
         * productInfo : null
         * isHot : 0
         * isHotPost : 0
         * content : “蓝瘦香菇”迅速走红网络，出处就在这里啦~
         * linkId : null
         * source : 网络
         * playQty : 2
         * topTime : null
         * postTypeName : 趣事趣闻视频
         */

        private RxPost post;
        private String isAttented;
        /**
         * createTime : null
         * plateNavigationPic :
         * sort : null
         * isAttented : null
         * postQty : null
         * id : null
         * plateTypeCode : qushivideo
         * plateType : null
         * platePic : null
         * plateName : null
         * description : null
         * attentionQty : null
         * plateTypeId : 30
         * plateIntroduce : null
         */

        private RxPlate plate;
        private String isLiked;
        private String isOwner;
        private Object account;
        private String hasReply;

        public RxPost getPost() {
            return post;
        }

        public void setPost(RxPost post) {
            this.post = post;
        }

        public String getIsAttented() {
            return isAttented;
        }

        public void setIsAttented(String isAttented) {
            this.isAttented = isAttented;
        }

        public RxPlate getPlate() {
            return plate;
        }

        public void setPlate(RxPlate plate) {
            this.plate = plate;
        }

        public String getIsLiked() {
            return isLiked;
        }

        public void setIsLiked(String isLiked) {
            this.isLiked = isLiked;
        }

        public String getIsOwner() {
            return isOwner;
        }

        public void setIsOwner(String isOwner) {
            this.isOwner = isOwner;
        }

        public Object getAccount() {
            return account;
        }

        public void setAccount(Object account) {
            this.account = account;
        }

        public String getHasReply() {
            return hasReply;
        }

        public void setHasReply(String hasReply) {
            this.hasReply = hasReply;
        }
    }
}
