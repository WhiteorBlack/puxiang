package com.puxiang.mall.base;

import android.view.View;

/**
 * Desc :  用于异常页面
 * version : v1.0
 */

public interface ErrorShow {

    void showNoneView();

    void showNoneView(String tips);

    void showNoneView(View.OnClickListener clickListener);

    void showNoneView(String tips, View.OnClickListener clickListener);

    void hidNoneView();
}
