package com.puxiang.mall.model.data;

public class RxIntegralProduct {
    /**
     * productPicUrl : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201610/363fc48029f242069189059c35d930b790286.jpg
     * productMainPicUrl : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201610/363fc48029f242069189059c35d930b790286.jpg
     * productSpec : 不限
     * endTime : 2017-05-01 00:00:00
     * productState : 2
     * productType : 1
     * exchangeQty : 4
     * startTime : 2016-11-01 00:00:00
     * id : 26
     * needScore : 2500.0
     * exchangePercentage : 4%
     * productSalePrice : 49.0
     * productStock : 96
     * productMarketPrice : 49.0
     * productIntroduce : 2000毫安、体积小，重量轻，循环寿命长，兼容大部分手机及通讯数码设备
     * productName : MAQ魅格移动电源PS1
     */

    private String productPicUrl;
    private String productMainPicUrl;
    private String productSpec;
    private String endTime;
    private int productState;
    private int productType;
    private int exchangeQty;
    private String startTime;
    private int id;
    private double needScore;
    private String exchangePercentage;
    private double productSalePrice;
    private int productStock;
    private double productMarketPrice;
    private String productIntroduce;
    private String productName;

    public String getProductPicUrl() {
        return productPicUrl;
    }

    public void setProductPicUrl(String productPicUrl) {
        this.productPicUrl = productPicUrl;
    }

    public String getProductMainPicUrl() {
        return productMainPicUrl;
    }

    public void setProductMainPicUrl(String productMainPicUrl) {
        this.productMainPicUrl = productMainPicUrl;
    }

    public String getProductSpec() {
        return productSpec;
    }

    public void setProductSpec(String productSpec) {
        this.productSpec = productSpec;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public int getProductState() {
        return productState;
    }

    public void setProductState(int productState) {
        this.productState = productState;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }

    public int getExchangeQty() {
        return exchangeQty;
    }

    public void setExchangeQty(int exchangeQty) {
        this.exchangeQty = exchangeQty;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getNeedScore() {
        return needScore;
    }

    public void setNeedScore(double needScore) {
        this.needScore = needScore;
    }

    public String getExchangePercentage() {
        return exchangePercentage;
    }

    public void setExchangePercentage(String exchangePercentage) {
        this.exchangePercentage = exchangePercentage;
    }

    public double getProductSalePrice() {
        return productSalePrice;
    }

    public void setProductSalePrice(double productSalePrice) {
        this.productSalePrice = productSalePrice;
    }

    public int getProductStock() {
        return productStock;
    }

    public void setProductStock(int productStock) {
        this.productStock = productStock;
    }

    public double getProductMarketPrice() {
        return productMarketPrice;
    }

    public void setProductMarketPrice(double productMarketPrice) {
        this.productMarketPrice = productMarketPrice;
    }

    public String getProductIntroduce() {
        return productIntroduce;
    }

    public void setProductIntroduce(String productIntroduce) {
        this.productIntroduce = productIntroduce;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
