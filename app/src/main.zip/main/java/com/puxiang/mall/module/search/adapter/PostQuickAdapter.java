package com.puxiang.mall.module.search.adapter;

import com.puxiang.mall.adapter.BindingViewHolder;
import com.puxiang.mall.adapter.EasyBindQuickAdapter;
import com.puxiang.mall.model.data.RxPostInfo;

public class PostQuickAdapter extends EasyBindQuickAdapter<RxPostInfo> {
    public PostQuickAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void easyConvert(BindingViewHolder holder, RxPostInfo item) {

    }
}
