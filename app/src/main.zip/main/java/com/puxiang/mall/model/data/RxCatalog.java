package com.puxiang.mall.model.data;

public class RxCatalog {

    /**
     * sort : 1
     * sysTypeName : 游戏系列
     * parentTypeId : 1
     * catalogId : 3964
     * typeLevel : 2
     * typeCover :
     */

    private int sort;
    private String sysTypeName;
    private int parentTypeId;
    private String catalogId;
    private int typeLevel;
    private String typeCover;

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }

    public String getSysTypeName() {
        return sysTypeName;
    }

    public void setSysTypeName(String sysTypeName) {
        this.sysTypeName = sysTypeName;
    }

    public int getParentTypeId() {
        return parentTypeId;
    }

    public void setParentTypeId(int parentTypeId) {
        this.parentTypeId = parentTypeId;
    }

    public String getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(String catalogId) {
        this.catalogId = catalogId;
    }

    public int getTypeLevel() {
        return typeLevel;
    }

    public void setTypeLevel(int typeLevel) {
        this.typeLevel = typeLevel;
    }

    public String getTypeCover() {
        return typeCover;
    }

    public void setTypeCover(String typeCover) {
        this.typeCover = typeCover;
    }
}
