package com.puxiang.mall.model.data;

import com.chad.library.adapter.base.entity.SectionEntity;


public class EsportSection extends SectionEntity<RxEsport> {
    public EsportSection(boolean isHeader, String header) {
        super(isHeader, header);
    }

    public EsportSection(RxEsport esport) {
        super(esport);
    }
}
