package com.puxiang.mall.model.data;

import java.util.List;

public class RxCommentInfo {

    /**
     * birthday :
     * sex : 2
     * viewName : 范德彪
     * nickname : 范德彪
     * userId : 372
     * userImage : http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/mine_head.png
     * userName : M000000359
     */

    private RxUserInfo commentUser;
    /**
     * commentUser : {"birthday":"","sex":2,"viewName":"范德彪","nickname":"范德彪","userId":372,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/mine_head.png","userName":"M000000359"}
     * post : null
     * replys : [{"byReplyUser":{"birthday":"","sex":2,"viewName":"范德彪","nickname":"范德彪","userId":372,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/mine_head.png","userName":"M000000359"},"commentUser":{"birthday":"2016-08-17","sex":1,"viewName":"张小凡@","nickname":"张小凡@","userId":16,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/9ba89887a50f4bde9f83ff058ccda09718261.jpg","userName":"M000000006"},"commentReply":{"id":357,"replyUserId":16,"reply":"2","byReplyUserId":372,"replyTime":"2016-12-01 11:17:15","commentId":2261}},{"byReplyUser":{"birthday":"","sex":2,"viewName":"范德彪","nickname":"范德彪","userId":372,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/mine_head.png","userName":"M000000359"},"commentUser":{"birthday":"2016-08-17","sex":1,"viewName":"张小凡@","nickname":"张小凡@","userId":16,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/9ba89887a50f4bde9f83ff058ccda09718261.jpg","userName":"M000000006"},"commentReply":{"id":356,"replyUserId":16,"reply":"1","byReplyUserId":372,"replyTime":"2016-12-01 11:16:39","commentId":2261}}]
     * isLiked : false
     * comment : {"id":2261,"commentQty":0,"commentTime":"2016-11-30 22:41:07","comment":"东北？地三鲜吧","commentUserId":372,"likeQty":0,"postId":2928}
     */

    private Object post;
    private boolean isLiked;
    /**
     * id : 2261
     * commentQty : 0
     * commentTime : 2016-11-30 22:41:07
     * comment : 东北？地三鲜吧
     * commentUserId : 372
     * likeQty : 0
     * postId : 2928
     */

    private RxComment comment;
    /**
     * byReplyUser : {"birthday":"","sex":2,"viewName":"范德彪","nickname":"范德彪","userId":372,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/mine_head.png","userName":"M000000359"}
     * commentUser : {"birthday":"2016-08-17","sex":1,"viewName":"张小凡@","nickname":"张小凡@","userId":16,"userImage":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201611/9ba89887a50f4bde9f83ff058ccda09718261.jpg","userName":"M000000006"}
     * commentReply : {"id":357,"replyUserId":16,"reply":"2","byReplyUserId":372,"replyTime":"2016-12-01 11:17:15","commentId":2261}
     */

    private List<RxReply> replys;

    public RxUserInfo getCommentUser() {
        return commentUser;
    }

    public void setCommentUser(RxUserInfo commentUser) {
        this.commentUser = commentUser;
    }

    public Object getPost() {
        return post;
    }

    public void setPost(Object post) {
        this.post = post;
    }

    public boolean getIsLiked() {
        return isLiked;
    }

    public void setIsLiked(boolean isLiked) {
        this.isLiked = isLiked;
    }

    public RxComment getComment() {
        return comment;
    }

    public void setComment(RxComment comment) {
        this.comment = comment;
    }

    public List<RxReply> getReplys() {
        return replys;
    }

    public void setReplys(List<RxReply> replys) {
        this.replys = replys;
    }
}

