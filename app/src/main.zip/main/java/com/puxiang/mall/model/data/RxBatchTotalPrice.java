package com.puxiang.mall.model.data;

/**
 * Created by zhaoyong bai on 2017/10/23.
 */

public class RxBatchTotalPrice {
    private double totalPrice;

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
