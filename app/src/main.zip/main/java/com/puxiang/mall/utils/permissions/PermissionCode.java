package com.puxiang.mall.utils.permissions;

public class PermissionCode {
    public static final int RG_CAMERA_PERM = 5000;
    public static final int RG_CALL_PHONE = 5001;
    public static final int RG_READ_EXTERNAL_STORAGE = 5002;
    public static final int RG_ACCESS_FINE_LOCATION = 5003;
    public static final int RG_RECORD_AUDIO = 5004;
    public static final int RG_GET_ACCOUNTS = 5005;
    public static final int RG_LOCATION=5006;
}
