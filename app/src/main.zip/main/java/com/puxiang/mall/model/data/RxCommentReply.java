package com.puxiang.mall.model.data;


public class RxCommentReply {
    private int id;
    private int replyUserId;
    private String reply;
    private int byReplyUserId;
    private String replyTime;
    private int commentId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReplyUserId() {
        return replyUserId;
    }

    public void setReplyUserId(int replyUserId) {
        this.replyUserId = replyUserId;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public int getByReplyUserId() {
        return byReplyUserId;
    }

    public void setByReplyUserId(int byReplyUserId) {
        this.byReplyUserId = byReplyUserId;
    }

    public String getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(String replyTime) {
        this.replyTime = replyTime;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }
}
