package com.puxiang.mall.network.retrofit;

/**
 * 保存一些私密数据
 */
public class SecretConstant {
    /**
     * Somic服务器地址
     */
    public final static String API_HOST = "https://api.esomic.com/";
//    public final static String API_HOST = "https://test.api.esomic.com/";

}
