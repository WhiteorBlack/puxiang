package com.puxiang.mall.model.data;

import java.util.List;

public class RxTest {
    private List<RxPlateType> list;

    public List<RxPlateType> getList() {
        return list;
    }

    public void setList(List<RxPlateType> list) {
        this.list = list;
    }

    @Override
    public String toString() {
        return "{list=" + list +'}';
    }
}
