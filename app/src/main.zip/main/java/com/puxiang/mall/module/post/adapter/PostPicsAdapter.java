package com.puxiang.mall.module.post.adapter;

import com.puxiang.mall.adapter.BindingViewHolder;
import com.puxiang.mall.adapter.EasyBindQuickAdapter;

import java.util.List;

public class PostPicsAdapter extends EasyBindQuickAdapter<String> {


    public PostPicsAdapter(int layoutResId, List<String> data) {
        super(layoutResId, data);
    }

    @Override
    protected void easyConvert(BindingViewHolder holder, String item) {

    }
}
