package com.puxiang.mall.model.data;

import java.util.List;


public class RxEsportList {

    /**
     * totalCount : 15
     * list : [{"id":9,"distance":"","linkPhone":"11","isAttented":0,"address":"广东省广州市天河区天河路490号","name":"硕美科电竞馆2","lowestPerHour":11,"longitude":"113.33499848842621","feature":"2","latitude":"23.13278295729362","pic":{"description":"","pic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201705/5c7d6c249ba242f3bc0f6d3249eabdf543690.jpg?2400x1800"},"code":"2"},{"id":15,"distance":"","linkPhone":"11","isAttented":0,"address":"广东省广州市天河区天河路490号","name":"硕美科电竞馆2","lowestPerHour":11,"longitude":"113.33499848842621","feature":"2","latitude":"23.13278295729362","pic":{"description":"","pic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201705/5c7d6c249ba242f3bc0f6d3249eabdf543690.jpg?2400x1800"},"code":"2"},{"id":6,"distance":"","linkPhone":"","isAttented":0,"address":"上海市上海市黄浦区人民大道200号","name":"上海硕美科电竞馆","lowestPerHour":10,"longitude":"121.47389888763428","feature":"信誉好","latitude":"31.23030730373382","pic":{"description":"","pic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201705/320e83f5d92c4665b2aa5662209f3b1490336.jpg?750x360"},"code":"shanghai"},{"id":12,"distance":"","linkPhone":"","isAttented":0,"address":"上海市上海市黄浦区人民大道200号","name":"上海硕美科电竞馆","lowestPerHour":10,"longitude":"121.47389888763428","feature":"信誉好","latitude":"31.23030730373382","pic":{"description":"","pic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201705/320e83f5d92c4665b2aa5662209f3b1490336.jpg?750x360"},"code":"shanghai"},{"id":2,"distance":"","linkPhone":"","isAttented":0,"address":"广东省广州市天河区天河路594号","name":"硕美科电竞馆百脑汇店","lowestPerHour":5,"longitude":"113.33957970142365","feature":"美女多","latitude":"23.134460201482835","pic":{"description":"","pic":"http://somicshop.oss-cn-shenzhen.aliyuncs.com/attached/images/201705/320e83f5d92c4665b2aa5662209f3b1490336.jpg?750x360"},"code":"0002"}]
     */

    private int totalCount;
    private List<RxEsport> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<RxEsport> getList() {
        return list;
    }

    public void setList(List<RxEsport> list) {
        this.list = list;
    }

}
